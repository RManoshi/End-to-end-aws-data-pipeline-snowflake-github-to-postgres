
import sys #Imports Python’s system module , Used to read command-line arguments passed to the Glue job
from awsglue.transforms import * #Glue’s built-in transformation helpers
from awsglue.utils import getResolvedOptions  #Reads parameters passed to the Glue job
from pyspark.context import SparkContext  #Creates the Spark engine
from awsglue.context import GlueContext #Wraps Spark with Glue-specific features (catalog, jobs, bookmarks)
from awsglue.job import Job #Manages Glue job lifecycle (start, commit)

from pyspark.sql.functions import col, year, month, dayofmonth, concat_ws, to_date, lit #col-Reference a column , month-Extract month from date,dayofmonth-Extract day,concat_ws-Join strings with separator,to_date-Convert string to date , lit -Create a constant value
from pyspark.sql.types import DateType, TimestampType #Used to check column data types,So only date/timestamp columns are modified

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME']) #Glue automatically passes job parameters ,This extracts the job name so Glue can track execution

sc = SparkContext()  #Starts Spark engine
glueContext = GlueContext(sc) #Adds Glue features on top of Spark
spark = glueContext.spark_session #Spark SQL session (used to read/write data)
job = Job(glueContext)  #Registers this script as a Glue job,Enables job bookmarking, retries, logging
job.init(args['JOB_NAME'], args)


raw_bucket = "s3://dep1-tpch-data-lake/raw/" #raw/ → Original source data (unchanged)
curated_bucket = "s3://dep1-tpch-data-lake/curated/" #curated/ → Cleaned & transformed data

tables = ["customer", "lineitem", "nation", "orders","part", "partsupp",
"region", "supplier" ] #Tables to process in a loop

for table in tables: #Processes one table at a time
    df = ( 
    spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .csv(f"{raw_bucket}{table}/*.csv.gz")
        ) ##Reads Parquet files 

    
    for field in df.schema.fields: #Iterates over every column definition
        if isinstance(field.dataType, (DateType, TimestampType)):  #Checks if column is: DATE or TIMESTAMP ,Ensures only date-related columns are transformed
            df = df.withColumn(
                field.name, #Replaces the existing column with a new value
                to_date( #Final output type to DATE
                    concat_ws(
                        "-",
                        lit(2024),
                        month(col(field.name)),
                        dayofmonth(col(field.name))
                    ),
                    "yyyy-M-d" #Year replaced , Month preserved, Day preserved
                )
            )
    df.write.mode("overwrite").parquet(f"{curated_bucket}{table}/") #Writes clean data to curated zone

job.commit() #Signals Glue that the job finished successfully ,Required for bookmarks & accurate job status
