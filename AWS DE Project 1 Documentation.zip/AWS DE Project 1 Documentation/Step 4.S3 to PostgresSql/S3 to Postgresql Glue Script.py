
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from urllib.parse import urlparse
import boto3

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# ============================
# 1. First source: your original CSV file (Sales Performance)
# ============================
csv_s3_path = "s3://dep1-sales-performance-data-s3/Supply Performance Data.csv"

print("Loading CSV file...")
df_csv = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load(csv_s3_path)

dyf_csv = DynamicFrame.fromDF(df_csv, glueContext, "salesperformance_dyf")

glueContext.write_dynamic_frame.from_jdbc_conf(
    frame=dyf_csv,
    catalog_connection="Postgresql connection",   # ← your Glue connection name
    connection_options={
        "dbtable": "public.salesperformance",
        "database": "postgres",
        "preactions": "DROP TABLE IF EXISTS public.salesperformance;"  # optional: clean reload
    }
)

# ============================
# 2. Second source: Snowflake-exported data (multiple Parquet folders = multiple tables)
# ============================
snowflake_base_path = "s3://dep1-tpch-data-lake/curated/"   # ← change this
# Example: s3://my-company-snowflake-exports/2025-12-08/database/schema/

parsed = urlparse(snowflake_base_path)
bucket = parsed.netloc
prefix = parsed.path.lstrip('/')

s3 = boto3.client('s3')
paginator = s3.get_paginator('list_objects_v2')
pages = paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter='/')

print("Discovering Snowflake tables (folders with Parquet files)...")
for page in pages:
    if 'CommonPrefixes' not in page:
        continue
        
    for obj in page['CommonPrefixes']:
        folder_prefix = obj['Prefix']
        table_name = folder_prefix.rstrip('/').split('/')[-1].lower()  # use lowercase to be safe
        
        # Skip if folder is empty or doesn't contain parquet files
        parquet_path = f"s3://{bucket}/{folder_prefix}"
        
        print(f"Processing table: {table_name} ← {parquet_path}")
        
        try:
            df = spark.read.parquet(parquet_path)
            
            if df.rdd.isEmpty():
                print(f"  → Skipping empty table: {table_name}")
                continue
                
            dyf = DynamicFrame.fromDF(df, glueContext, f"{table_name}_dyf")
            
            glueContext.write_dynamic_frame.from_jdbc_conf(
                frame=dyf,
                catalog_connection="Postgresql connection",
                connection_options={
                    "dbtable": f"public.{table_name}",
                    "database": "postgres",
                    # Optional: always start clean (uncomment if you want truncate+reload)
                    # "preactions": f"DROP TABLE IF EXISTS public.{table_name};"
                }
            )
            print(f"  → Successfully loaded {table_name}")
            
        except Exception as e:
            print(f"  → Failed to load {table_name}: {str(e)}")
            # Continue with next table even if one fails
            continue

job.commit()
print("Job completed: both sources loaded into PostgreSQL")
